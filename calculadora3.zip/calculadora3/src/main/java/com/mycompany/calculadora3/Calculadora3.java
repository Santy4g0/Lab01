/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.calculadora3;

import java.util.Scanner;

/**
 *
 * @author juand
 */
public class Calculadora3 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean continuar = true;

        while (continuar) {
            System.out.println("Seleccione una operación:");
            System.out.println("1. Suma");
            System.out.println("2. Resta");
            System.out.println("3. Multiplicación");
            System.out.println("4. División");
            System.out.println("5. Seno");
            System.out.println("6. Coseno");
            System.out.println("7. Tangente");
            System.out.println("8. Raíz enésima");
            System.out.println("9. Potencia enésima");
            System.out.println("10. Calcular IVA");
            System.out.println("0. Salir");

            int opcion = scanner.nextInt();
            scanner.nextLine(); 
            
            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el primer número: ");
                    double num1 = scanner.nextDouble();
                    System.out.print("Ingrese el segundo número: ");
                    double num2 = scanner.nextDouble();
                    System.out.println("Resultado: " + suma(num1, num2));
                    break;
                case 2:
                    System.out.print("Ingrese el primer número: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese el segundo número: ");
                    num2 = scanner.nextDouble();
                    System.out.println("Resultado: " + resta(num1, num2));
                    break;
                case 3:
                    System.out.print("Ingrese el primer número: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese el segundo número: ");
                    num2 = scanner.nextDouble();
                    System.out.println("Resultado: " + multiplicacion(num1, num2));
                    break;
                case 4:
                    System.out.print("Ingrese el primer número: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese el segundo número: ");
                    num2 = scanner.nextDouble();
                    if (num2 == 0) {
                        System.out.println("Error: No se puede dividir entre cero.");
                    } else {
                        System.out.println("Resultado: " + division(num1, num2));
                    }
                    break;
                case 5:
                    System.out.print("Ingrese el ángulo en radianes: ");
                    double angulo = scanner.nextDouble();
                    System.out.println("Resultado: " + seno(angulo));
                    break;
                case 6:
                    System.out.print("Ingrese el ángulo en radianes: ");
                    angulo = scanner.nextDouble();
                    System.out.println("Resultado: " + coseno(angulo));
                    break;
                case 7:
                    System.out.print("Ingrese el ángulo en radianes: ");
                    angulo = scanner.nextDouble();
                    System.out.println("Resultado: " + tangente(angulo));
                    break;
                case 8:
                    System.out.print("Ingrese el número: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese el índice de la raíz: ");
                    int indiceRaiz = scanner.nextInt();
                    System.out.println("Resultado: " + raizEnesima(num1, indiceRaiz));
                    break;
                case 9:
                    System.out.print("Ingrese la base: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese el exponente: ");
                    num2 = scanner.nextDouble();
                    System.out.println("Resultado: " + potenciaEnesima(num1, num2));
                    break;
                case 10:
                    System.out.print("Ingrese el valor: ");
                    num1 = scanner.nextDouble();
                    System.out.print("Ingrese el porcentaje de IVA: ");
                    double porcentajeIva = scanner.nextDouble();
                    System.out.println("IVA: " + calcularIVA(num1, porcentajeIva));
                    break;
                case 0:
                    continuar = false;
                    break;
                default:
                    System.out.println("Opción inválida.");
            }
        }
        scanner.close();
    }

    public static double suma(double num1, double num2) {
        return num1 + num2;
    }

    public static double resta(double num1, double num2) {
        return num1 - num2;
    }

    public static double multiplicacion(double num1, double num2) {
        return num1 * num2;
    }

    public static double division(double num1, double num2) {
        return num1 / num2;
    }

    public static double seno(double angulo) {
        return Math.sin(angulo);
    }

    public static double coseno(double angulo) {
        return Math.cos(angulo);
    }

    public static double tangente(double angulo) {
        return Math.tan(angulo);
    }

    public static double raizEnesima(double num, int indice) {
        return Math.pow(num, 1.0 / indice);
    }

    public static double potenciaEnesima(double base, double exponente) {
        return Math.pow(base, exponente);
    }

    public static double calcularIVA(double valor, double porcentaje) {
        return valor * (porcentaje / 100);
    }
}


